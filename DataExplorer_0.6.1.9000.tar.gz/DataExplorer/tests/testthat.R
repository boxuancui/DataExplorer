library(testthat)
library(DataExplorer)

test_check("DataExplorer")
